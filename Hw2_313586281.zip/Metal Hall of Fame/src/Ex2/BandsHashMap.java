package Ex2;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class BandsHashMap implements Map<String, Band>{

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean containsKey(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsValue(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Entry<String, Band>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Band get(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<String> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Band put(String arg0, Band arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putAll(Map<? extends String, ? extends Band> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Band remove(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Collection<Band> values() {
		// TODO Auto-generated method stub
		return null;
	}

}
