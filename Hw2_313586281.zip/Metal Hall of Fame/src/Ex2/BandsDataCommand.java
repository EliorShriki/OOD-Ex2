package Ex2;

public interface BandsDataCommand {
    public void execute();

    public void undo();
}
