package Ex2;

import java.io.IOException;
import java.util.Comparator;

public class BandsDataControllerImpl implements BandsDataController {

	private static BandsDataControllerImpl instance = null;
	
	private BandsDataControllerImpl() {
		// TODO Auto-generated constructor stub
	}
	
	public static BandsDataControllerImpl getInstance() {
		if(instance==null)
			instance = new BandsDataControllerImpl();
		return instance;
	}
	
	@Override
	public Band previous() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Band next() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sort(Comparator<Band> comparator) {
		// TODO Auto-generated method stub

	}

	@Override
	public void add(Band band) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub

	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub

	}

	@Override
	public void revert() {
		// TODO Auto-generated method stub

	}

	@Override
	public void save() throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public Band getBandByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
