package Ex2;

import java.io.IOException;

public class BandDataAccessObject implements BandDataAccess {

	private static BandDataAccessObject instance = null;
	
	private BandDataAccessObject() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public BandsArrayList readAllBands() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static BandDataAccessObject getInstance(){
		if(instance==null)
			instance=new BandDataAccessObject();
		return instance;
	}

	@Override
	public BandsHashMap getBandsMappedByName() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveBands(Band[] bands) throws IOException {
		// TODO Auto-generated method stub

	}

}
